def find_g(p):
    g = -1
    for i in range(1, p):
        for j in range(1, p):
            if j==p-1:
                g = i
                break
            if (i**j)%p==1:
                print(f"because {i} mod {j} = 1, {j} is not 3228, so {i} is not root")
                break
        if g > 0:

            return g
            break


def NTT(A, g, p):

    # get the length of the list
    n = len(A)
    if n==1:
        return A

    # get gn
    gn = g**int((p-1)/n)%p

    # Split the array into odd and even arrays
    Ae = [0]*int(n/2)
    Ao = [0]*int(n/2)
    for i in range(int(n/2)):
        Ae[i] = A[2*i]
        Ao[i] = A[2*i+1]

    # Recursion
    ye = NTT(Ae, g, p)
    yo = NTT(Ao, g, p)

    # Butterfly
    y = [0] * n
    for j in range(int(n/2)):
        mod1= ye[j]%p
        mod2 = (gn**j)*yo[j]%p

        y[j] = (mod1+mod2)%p
        y[j+int(n/2)] = (mod1-mod2)%p
    return y


def INTT(yC, g, p):

    # use NTT
    y = NTT(yC, g, p)
    n = len(y)

    # get 1/n
    n_1 = (n ** (p - 2) % p)
    y_r = [0] * n

    # the result multiply 1/n
    y_r[0] = y[0] * n_1 % p
    for i in range(1, n):
        y_r[n - i] = y[i] * n_1 % p
    return y_r

def Mult(yA, yB, p):
    n = len(yA)
    yC = [0] * n
    for i in range(n):
        yC[i] = yA[i]*yB[i]%p

    # print("finish Mult")
    return yC